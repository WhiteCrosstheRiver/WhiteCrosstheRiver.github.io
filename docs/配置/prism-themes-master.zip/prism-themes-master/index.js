const path = require('path');

module.exports = {
	themesDirectory: path.resolve(__dirname, 'themes')
};
