# Security Policy

## Reporting a vulnerability

If you discover a security issue, **do not** file a public issue. Instead, please send a report privately to msrd0000@gmail.com, and we will correspond with you from there.
