---
name: 🐛 Bug Report
about: Submit a bug report to help us improve
labels: "bug"
---

## 🐛 Bug Report

<!-- A clear and concise description of what the bug is. -->

