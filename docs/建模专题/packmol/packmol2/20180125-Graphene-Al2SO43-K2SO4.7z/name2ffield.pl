#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

my $doc = $Documents{"test.xsd"};
my $atoms = $doc->Atoms;

foreach my $atom (@$atoms) {
    # printf "Pre: ElementName = %s Name = %s ForcefieldType = %s\n", $atom->ElementName, $atom->Name, $atom->ForcefieldType;
    $atom->ForcefieldType = $atom->Name;
    # printf "Now: ElementName = %s Name = %s ForcefieldType = %s\n", $atom->ElementName, $atom->Name, $atom->ForcefieldType;
}

