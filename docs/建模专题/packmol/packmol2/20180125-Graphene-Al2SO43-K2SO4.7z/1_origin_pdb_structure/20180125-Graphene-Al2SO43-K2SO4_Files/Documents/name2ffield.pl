#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

my $doc = $Documents{"structure_Gra_Al2SO4_3-0.6M.xsd"};
my $atoms = $doc->Atoms;

foreach my $atom (@$atoms) {
    $atom->ForcefieldType = $atom->Name;
}

